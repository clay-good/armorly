/**
 * Popup Script for Armorly
 * 
 * Handles the extension popup UI and user interactions
 */

document.addEventListener('DOMContentLoaded', async () => {
    console.log('[Armorly] Popup loaded');

    try {
        // Initialize UI
        await loadProtectionStatus();
        await loadStatistics();
        await loadPerformanceStats();
        await loadCurrentPageInfo();
        await loadAIAgentStatus();
        await loadThreatLog();

        // Set up event listeners
        setupEventListeners();

        console.log('[Armorly] Popup initialization complete');
    } catch (error) {
        console.error('[Armorly] Error initializing popup:', error);
    }
});

/**
 * Load protection status from background
 */
async function loadProtectionStatus() {
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'GET_PROTECTION_STATUS'
        });

        if (response.success) {
            const toggle = document.getElementById('protection-toggle');
            const statusIndicator = document.getElementById('status-indicator');
            const statusText = document.getElementById('status-text');

            toggle.checked = response.enabled;

            if (response.enabled) {
                statusIndicator.style.background = '#10b981';
                statusText.textContent = 'Protected';
                statusText.style.color = '#10b981';
            } else {
                statusIndicator.style.background = '#ef4444';
                statusText.textContent = 'Disabled';
                statusText.style.color = '#ef4444';
            }
        }
    } catch (error) {
        console.error('[Armorly] Error loading protection status:', error);
    }
}

/**
 * Load statistics from background
 */
async function loadStatistics() {
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'GET_THREAT_LOG'
        });

        if (response.success) {
            const { statistics } = response;

            // Update threats blocked
            document.getElementById('threats-blocked').textContent = 
                statistics.totalThreatsBlocked || 0;

            // Calculate pages scanned (estimate based on threats)
            const pagesScanned = Math.max(statistics.totalThreatsBlocked, 10);
            document.getElementById('pages-scanned').textContent = pagesScanned;
        }
    } catch (error) {
        console.error('[Armorly] Error loading statistics:', error);
    }
}

/**
 * Load performance statistics
 */
async function loadPerformanceStats() {
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'GET_PERFORMANCE_STATS'
        });

        if (response.success) {
            const { stats } = response;

            // Update average overhead
            document.getElementById('avg-overhead').textContent = stats.averageOverhead;

            // Update performance status
            const perfStatusEl = document.getElementById('perf-status');
            if (stats.withinThreshold) {
                perfStatusEl.textContent = '✅';
                perfStatusEl.title = 'Performance is optimal';
            } else {
                perfStatusEl.textContent = '⚠️';
                perfStatusEl.title = 'Performance may be slow';
            }
        }
    } catch (error) {
        console.error('[Armorly] Error loading performance stats:', error);
    }
}

/**
 * Load current page information
 */
async function loadCurrentPageInfo() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (!tab || !tab.url) {
            document.getElementById('current-url').textContent = 'No active tab';
            return;
        }

        // Check if URL is accessible (not chrome://, about:, etc.)
        const url = tab.url;
        const isAccessible = url.startsWith('http://') || url.startsWith('https://');

        if (!isAccessible) {
            document.getElementById('current-url').textContent = 'Protected page';
            return;
        }

        try {
            const urlObj = new URL(url);
            document.getElementById('current-url').textContent = urlObj.hostname;

            // Try to check if page has threats (content script may not be loaded yet)
            const response = await chrome.tabs.sendMessage(tab.id, {
                type: 'GET_THREATS'
            });

            if (response && response.success) {
                const { summary } = response;
                updateThreatLevel(summary.totalScore || 0);
            }
        } catch (messageError) {
            // Content script not loaded yet or page doesn't support it
            // This is normal for new tabs or restricted pages
            console.log('[Armorly] Content script not available on this page');
        }
    } catch (error) {
        console.error('[Armorly] Error loading page info:', error);
        const currentUrlEl = document.getElementById('current-url');
        if (currentUrlEl) {
            currentUrlEl.textContent = 'Unable to scan';
        }
    }
}

/**
 * Update threat level badge
 *
 * @param {number} score - Threat score
 */
function updateThreatLevel(score) {
    const badge = document.querySelector('.threat-badge');

    if (score >= 70) {
        badge.className = 'threat-badge high';
        badge.textContent = 'High Risk';
    } else if (score >= 40) {
        badge.className = 'threat-badge medium';
        badge.textContent = 'Medium Risk';
    } else {
        badge.className = 'threat-badge safe';
        badge.textContent = 'Safe';
    }
}

/**
 * Load AI agent status for current tab
 */
async function loadAIAgentStatus() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        const response = await chrome.runtime.sendMessage({
            type: 'GET_AI_AGENT_STATUS',
            tabId: tab.id
        });

        const statusDiv = document.getElementById('ai-agent-status');
        const typeSpan = document.getElementById('ai-agent-type');
        const multiplierSpan = document.getElementById('ai-multiplier');

        if (response.success && response.agent) {
            // Show AI agent indicator
            statusDiv.style.display = 'block';

            // Format agent type name
            const agentNames = {
                'atlas': 'ChatGPT Atlas',
                'comet': 'Perplexity Comet',
                'browseros': 'BrowserOS',
                'generic': 'AI Agent'
            };

            typeSpan.textContent = agentNames[response.agent.type] || 'AI Agent';
            multiplierSpan.textContent = `${response.agent.threatMultiplier}x Protection`;

            console.log('[Armorly] AI agent active:', response.agent);
        } else {
            // Hide AI agent indicator
            statusDiv.style.display = 'none';
        }
    } catch (error) {
        console.error('[Armorly] Error loading AI agent status:', error);
        document.getElementById('ai-agent-status').style.display = 'none';
    }
}

/**
 * Load recent threat log
 */
async function loadThreatLog() {
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'GET_THREAT_LOG'
        });

        if (response.success) {
            const { threatLog } = response;
            displayThreats(threatLog.slice(0, 5)); // Show last 5 threats
        }
    } catch (error) {
        console.error('[Armorly] Error loading threat log:', error);
    }
}

/**
 * Display threats in the UI
 * 
 * @param {Array} threats - Array of threat objects
 */
function displayThreats(threats) {
    const threatList = document.getElementById('threat-list');

    if (!threats || threats.length === 0) {
        threatList.innerHTML = `
            <div class="empty-state">
                <span class="empty-icon">✓</span>
                <p>No threats detected today</p>
            </div>
        `;
        return;
    }

    threatList.innerHTML = threats.map(threat => {
        const url = new URL(threat.url);
        const timeAgo = formatTimeAgo(threat.timestamp);
        
        return `
            <div class="threat-item">
                <div class="threat-header">
                    <span class="threat-type">${threat.severity} Threat</span>
                    <span class="threat-time">${timeAgo}</span>
                </div>
                <div class="threat-domain">${url.hostname}</div>
            </div>
        `;
    }).join('');
}

/**
 * Format timestamp as relative time
 * 
 * @param {number} timestamp - Unix timestamp
 * @returns {string} Formatted time string
 */
function formatTimeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Protection toggle
    document.getElementById('protection-toggle').addEventListener('change', async (e) => {
        const enabled = e.target.checked;
        
        try {
            await chrome.runtime.sendMessage({
                type: enabled ? 'ENABLE_PROTECTION' : 'DISABLE_PROTECTION'
            });
            
            await loadProtectionStatus();
        } catch (error) {
            console.error('[Armorly] Error toggling protection:', error);
            e.target.checked = !enabled; // Revert on error
        }
    });

    // Scan page button
    document.getElementById('scan-page').addEventListener('click', async () => {
        console.log('[Armorly] Scan page button clicked');
        const button = document.getElementById('scan-page');
        button.textContent = 'Scanning...';
        button.disabled = true;

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            console.log('[Armorly] Current tab:', tab.url);

            // Send message to content script to trigger scan
            const response = await chrome.tabs.sendMessage(tab.id, {
                type: 'FORCE_SCAN'
            });

            console.log('[Armorly] Scan response:', response);

            if (response && response.success) {
                await loadCurrentPageInfo();
                await loadThreatLog();
                button.textContent = '✓ Scan Complete';

                setTimeout(() => {
                    button.textContent = 'Scan This Page';
                    button.disabled = false;
                }, 2000);
            } else {
                throw new Error('Scan failed');
            }
        } catch (error) {
            console.error('[Armorly] Error scanning page:', error);
            button.textContent = 'Scan Failed';

            setTimeout(() => {
                button.textContent = 'Scan This Page';
                button.disabled = false;
            }, 2000);
        }
    });

    // Check memory button
    document.getElementById('check-memory').addEventListener('click', () => {
        console.log('[Armorly] Check memory button clicked');
        chrome.tabs.create({
            url: 'https://chatgpt.com/settings/data-controls'
        });
    });

    // Performance report button
    document.getElementById('view-performance').addEventListener('click', async () => {
        console.log('[Armorly] Performance report button clicked');
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'GET_PERFORMANCE_REPORT'
            });

            if (response.success) {
                showPerformanceReport(response.report);
            }
        } catch (error) {
            console.error('[Armorly] Error loading performance report:', error);
        }
    });

    // Settings button
    document.getElementById('open-settings').addEventListener('click', () => {
        console.log('[Armorly] Settings button clicked');
        chrome.runtime.openOptionsPage();
    });

    // Documentation link
    document.getElementById('view-docs').addEventListener('click', (e) => {
        console.log('[Armorly] Documentation link clicked');
        // Don't prevent default - let the link work naturally
    });
}

/**
 * Show performance report in alert
 * @param {Object} report - Performance report
 */
function showPerformanceReport(report) {
    const { summary, operations, recommendations } = report;

    let message = '📊 PERFORMANCE REPORT\n\n';
    message += `Status: ${summary.status}\n`;
    message += `Total Scans: ${summary.totalScans}\n`;
    message += `Total Threats: ${summary.totalThreats}\n`;
    message += `Average Overhead: ${summary.averageOverhead}\n\n`;

    message += '⏱️ OPERATIONS:\n';
    message += `DOM Scans: ${operations.domScans.count} (avg: ${operations.domScans.average})\n`;
    message += `Pattern Matches: ${operations.patternMatches.count} (avg: ${operations.patternMatches.average})\n`;
    message += `CSRF Checks: ${operations.csrfChecks.count} (avg: ${operations.csrfChecks.average})\n`;
    message += `Memory Checks: ${operations.memoryChecks.count} (avg: ${operations.memoryChecks.average})\n\n`;

    message += '💡 RECOMMENDATIONS:\n';
    recommendations.forEach(rec => {
        message += `${rec}\n`;
    });

    alert(message);
}
